import java.util.List;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

class AtomarSummer implements Runnable{
	private final CyclicBarrier barrier;
	private final int[] array;
	private final List<Long> longs;
	private int start, end;

	public AtomarSummer(CyclicBarrier barrier, int[] array, int maxPart, int currentPart, List<Long> longs){
		this.barrier = barrier;
		this.array = array;
		this.longs = longs;
		start = (int) ((double) array.length / maxPart * currentPart);
		end = (int) ((double) array.length / maxPart * (currentPart + 1) - 1);
	}

	@Override
	public void run(){
		long sum = 0;
		for (int i = start; i < end; i++)
			sum += array[i];
		
		longs.add(sum);

		try{
			barrier.await();
		}catch (InterruptedException e){
			e.printStackTrace();
		} catch (BrokenBarrierException e){
			e.printStackTrace();
		}
	}

}