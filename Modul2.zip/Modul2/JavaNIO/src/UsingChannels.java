import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class UsingChannels {

	public static void main(String[] args) {
		try {
			FileInputStream in = new FileInputStream("text.txt");
			FileChannel inChannel = in.getChannel();
			ByteBuffer buffer = ByteBuffer.allocate(1024);
			inChannel.read(buffer);
			buffer.flip();
			for(int index = 0; index < buffer.limit(); ++index)
						System.out.print((char) buffer.get(index));
			
			System.out.println();
			
			in.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
