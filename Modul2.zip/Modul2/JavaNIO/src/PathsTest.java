import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class PathsTest {

	public static void main(String[] args) throws IOException {
		Path path1 = Paths.get("c:", "windows", "system");
		Path path2 = Path.of("c:", "windows", "system");  // Java 11
		Path path3 = FileSystems.getDefault().getPath("c:", "windows", "system");
		
		System.out.println(path1);
		System.out.println(path2);
		System.out.println(path3);
		
		System.out.println(Paths.get("/"));
		Path root = Paths.get("\\");
		System.out.println(root.getNameCount());
		System.out.println(root.getFileName());
		System.out.println();
		FileSystems.getDefault().getRootDirectories().forEach(System.out::println);
		System.out.println("-----------------------");
		System.out.println(FileSystems.getDefault().getRootDirectories().iterator().next().getRoot());
		Files.lines(Path.of("text.txt")).forEach(System.out::println);
//		Files.lines(Path.of("text.txt")).forEach(e -> System.out.println(e));
		System.out.println("***********************************");
		Path datei = Path.of("text.txt");
		List<String> inhalt = Files.readAllLines(datei);
		inhalt.forEach(System.out::println);
		

		
	}

}
