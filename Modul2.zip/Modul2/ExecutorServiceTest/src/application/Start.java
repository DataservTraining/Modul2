package application;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Start {

	public static void main(String[] args) throws InterruptedException {
		UhrenRunnable uhr = new UhrenRunnable();
		ZaehlerRunnable zaehler = new ZaehlerRunnable();
		ExecutorService executor = Executors.newCachedThreadPool();
//		executor.execute(uhr);
		executor.execute(zaehler);
		
		Thread.sleep(2000);
		
//		executor.execute(uhr);
		executor.execute(zaehler);
		Thread.sleep(1000);
		executor.shutdownNow();
//		executor.execute(zaehler);
//		executor.execute(uhr);
		
		ScheduledExecutorService scheduledExecutor = Executors.newScheduledThreadPool(4);
//		scheduledExecutor.schedule(zaehler, 5, TimeUnit.SECONDS);
		scheduledExecutor.scheduleAtFixedRate(zaehler, 1, 20, TimeUnit.SECONDS);
		
		
	}

}
