package application;

import java.time.Instant;

public class UhrenRunnable implements Runnable{
	private boolean running = true;

	@Override
	public void run() {
		while (running) {
			Instant now = Instant.now();
			System.out.println(Thread.currentThread().getName() + ": " + now);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}
	}
	
	public void uhrStoppen() {
		running = false;
	}

}
