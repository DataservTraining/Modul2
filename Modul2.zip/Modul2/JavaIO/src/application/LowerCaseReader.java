package application;

import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;

public class LowerCaseReader extends FilterReader {

	protected LowerCaseReader(Reader in) {
		super(in);
	}

	@Override
	public int read() throws IOException {
		// TODO Auto-generated method stub
		return Character.toLowerCase((char)super.read());
	}

	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		int l = super.read(cbuf, off, len);
		for(int index = off; index < off + len; ++index)
			cbuf[index] = Character.toLowerCase(cbuf[index]);
		return l;
	}

	

	
	
}
