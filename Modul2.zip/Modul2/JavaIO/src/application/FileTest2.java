package application;

import java.io.File;

public class FileTest2 {

	public static void main(String[] args) {
		File file = new File("test\\dir1\\dir2");
		System.out.println(file.exists());
		boolean ok = file.mkdir();
		System.out.println(ok);
		ok = file.mkdirs();
		System.out.println(ok);

		File[] roots = File.listRoots();
		for (var root : roots) {
			System.out.println(root.getAbsolutePath());
		}

		String[] fileNames = roots[0].list();

		for (var v : fileNames) {
			System.out.println(v);
		}

		File[] files = roots[0].listFiles();

		System.out.println("==========================================");
		for (var f : files) {
			System.out.println(f.getName() + " isHidden: " + f.isHidden());
			if (f.isDirectory()) {
				String tab = "        ";
				File[] inhalt = f.listFiles();
				if(inhalt != null)
				for (var i : inhalt) {
					if (i.isDirectory()) {
						System.out.println(tab + "(d) " + i.getName());
					} else {
						System.out.println(tab + "(f) " + i.getName());
					}
				}
			} else {
				System.out.println(f.getName());
			}

		}

	}
}
