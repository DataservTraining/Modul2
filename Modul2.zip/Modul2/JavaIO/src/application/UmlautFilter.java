package application;

import java.io.FilterWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public class UmlautFilter extends FilterWriter {

	protected UmlautFilter(Writer out) {
		super(out);
	}

	@Override
	public void write(int c) throws IOException {
		char ch = (char) c;
		switch(ch) {
		case '�':
			super.write('a');
			super.write('e');
			break;
		case '�':
			super.write('o');
			super.write('e');
			break;
		case '�':
			super.write('u');
			super.write('e');
			break;
			
		case '�':
			super.write('A');
			super.write('e');
			break;
		case '�':
			super.write('O');
			super.write('e');
			break;
		case '�':
			super.write('U');
			super.write('e');
			break;
		case '�':
			super.write('s');
			super.write('s');
			break;
		default:
			super.write(c);
		}
		
	}

	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		
		char[] newChars = changeUmlaute(cbuf, len);
		
		super.write(newChars, off, newChars.length);
	}

	@Override
	public void write(String str, int off, int len) throws IOException {

		char[] chars = changeUmlaute(str.toCharArray(), len);
		super.write(new String(chars), off, chars.length);
	}
	
	private char[] changeUmlaute(char[] cbuf, int len) {
		List<Character> chars = new ArrayList<Character>();
		for(char ch : cbuf) {
		switch(ch) {
		case '�':
			chars.add('a');
			chars.add('e');
			++len;
			break;
		case '�':
			chars.add('o');
			chars.add('e');
			++len;
			break;
		case '�':
			chars.add('u');
			chars.add('e');
			++len;
			break;
			
		case '�':
			chars.add('A');
			chars.add('e');
			++len;
			break;
		case '�':
			chars.add('O');
			chars.add('e');
			++len;
			break;
		case '�':
			chars.add('U');
			chars.add('e');
			++len;
			break;
		case '�':
			chars.add('s');
			chars.add('s');
			++len;
			break;
		default:
			chars.add(ch);
		}
		}
		
		char[] newChars = new char[chars.size()];
		for(int index = 0; index < chars.size(); ++index) {
			newChars[index] = chars.get(index);
		}
		return newChars;
	}

}
