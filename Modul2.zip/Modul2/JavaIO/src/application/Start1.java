package application;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Start1 {

	public static void main(String[] args) {
		try {
			PrintWriter out = new PrintWriter(new FileWriter("text.txt", true));
			out.println("hallo welt");
			out.close();
			
			FileReader in = new FileReader("text.txt");
			UppercaseWriter out2 = new UppercaseWriter(new FileWriter("kopie.txt"));
			int ch;
//			while((ch = in.read()) != -1) {
//				out2.write(ch);
//			}
			char[] chars = new char[1024];
			
			while( (ch = in.read(chars)) != -1){
				out2.write(chars, 0, ch);
			}
			
			
			in.close();
			out2.close();
			
			LowerCaseReader in2 = new LowerCaseReader(new FileReader("kopie.txt"));
			
			while( (ch = in2.read(chars, 0, chars.length)) != -1){
				for(int index = 0; index < ch; ++index) {
					System.out.print(chars[index]);
				}
			}
			System.out.println();
			
			UmlautFilter out3 = new UmlautFilter(new FileWriter("umlaute.txt"));
			char[] umlaute = {'�', '\n','�', '\n','�', '\n','a', '\n','o', '\n','u', '\n','�', '\n','�', '\n','�', '\n','A', '\n','O', '\n','U', '\n','�', '\n'};
			out3.write(umlaute, 0, umlaute.length);
			out3.close();
			UmlautFilter out4 = new UmlautFilter(new FileWriter("umlaute2.txt"));
			
			out4.write(new String("�������"), 0, umlaute.length);
			out4.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
