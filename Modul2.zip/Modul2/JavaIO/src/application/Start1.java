package application;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Start1 {

	public static void main(String[] args) {
		try {
			PrintWriter out = new PrintWriter(new FileWriter("text.txt", true));
			out.println("hallo welt");
			out.close();
			
			FileReader in = new FileReader("text.txt");
			UppercaseWriter out2 = new UppercaseWriter(new FileWriter("kopie.txt"));
			int ch;
//			while((ch = in.read()) != -1) {
//				out2.write(ch);
//			}
			char[] chars = new char[1024];
			
			while( (ch = in.read(chars)) != -1){
				out2.write(chars, 0, ch);
			}
			
			
			in.close();
			out2.close();
			
			LowerCaseReader in2 = new LowerCaseReader(new FileReader("kopie.txt"));
			
			while( (ch = in2.read(chars, 0, chars.length)) != -1){
				for(int index = 0; index < ch; ++index) {
					System.out.print(chars[index]);
				}
			}
			System.out.println();
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
