package application;

import java.io.File;
import java.io.IOException;

public class FileTest {

	public static void main(String[] args) {
//		File file = new File("C:\\Users\\Guido\\Downloads\\ZoomInstaller.exe");
		System.out.println("PathSeparator: " + File.pathSeparator);
		System.out.println("Separator: " + File.separator);
		File file = new File("C:" + File.separator + "Windows\\System32\\aadtb.dll");
		
		System.out.println(file.exists());
		if(file.exists()) {
			System.out.println("absoluter Pfad: " + file.getAbsolutePath());
			System.out.println("Parent: " + file.getParent());
			System.out.println("Name: " + file.getName());
			System.out.println("Pfad: " + file.getPath());
			System.out.println("ParentFile: " + file.getParentFile());
			System.out.println("Gr��e: " + file.length());
			System.out.println("Gr��e: " + file.getUsableSpace());
//			file.delete();
			System.out.println("canExecute: " + file.canExecute());
			System.out.println("canRead: " + file.canRead());
			System.out.println("canWrite: " + file.canWrite());
			System.out.println("lastModified: " + file.lastModified());
			System.out.println("isDirectory: " + file.isDirectory());
			System.out.println("isFile: " + file.isFile());
			System.out.println("isHidden: " + file.isHidden());
			
		} else {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		

	}

}
