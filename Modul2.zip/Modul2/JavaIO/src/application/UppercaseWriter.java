package application;

import java.io.FilterWriter;
import java.io.IOException;
import java.io.Writer;

public class UppercaseWriter extends FilterWriter{

	protected UppercaseWriter(Writer out) {
		super(out);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void write(int c) throws IOException {
		char ch = (char) c;
		ch = Character.toUpperCase(ch);
		super.write(ch);
	}

	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		for(int index = off; index < off + len; ++index)
			cbuf[index] = Character.toUpperCase(cbuf[index]);
		super.write(cbuf, off, len);
	}

	@Override
	public void write(String str, int off, int len) throws IOException {
		String upperCases = str.toUpperCase();
		super.write(upperCases, off, len);
	}
	
	

}
