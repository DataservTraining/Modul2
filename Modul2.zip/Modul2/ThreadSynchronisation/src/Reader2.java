import java.util.concurrent.locks.ReentrantLock;

public class Reader2  implements Runnable{
	private Data3 feld;
	private ReentrantLock monitor;

	public Reader2(Data3 feld) {
		super();
		this.feld = feld;
		monitor = feld.getMonitor();
	}

	@Override
	public synchronized void run() {
		int temp = 0;
		boolean running = true;
		while (running) {
			
			monitor.lock();
				temp = feld.read();
				if (temp == -1) {
					running = false;
				} else {
					System.out.println("gelesen: " + temp);
				}
			monitor.unlock();
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Alles gelesen");

	}
}
