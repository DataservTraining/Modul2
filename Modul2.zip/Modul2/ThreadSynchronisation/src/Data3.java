
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Data3 {

	private int[] zahlen = new int[5];
	private int index;
	ReentrantLock monitor = new ReentrantLock();
	Condition condition = monitor.newCondition();
	
	public void write(int wert) {
		monitor.lock();
		if(index == zahlen.length) {
			try {
				condition.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		zahlen[index] = wert;
		++index;
		if(index==1) {
			condition.signalAll();
		}
		monitor.unlock();
	}
	
	public int read() {
		monitor.lock();
		int temp = zahlen[0];
		if(index == 0) {
			try {
				condition.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		for(int i = 0; i < index-1; ++i) {
			zahlen[i] = zahlen[i+1];
		}
		
		--index;
		if(index == zahlen.length-1) {
			condition.signalAll();
		}
		monitor.unlock();
		return temp;
	}

	public ReentrantLock getMonitor() {
		return monitor;
	}
	
	
}
