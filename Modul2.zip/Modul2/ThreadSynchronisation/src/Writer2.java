import java.util.concurrent.locks.ReentrantLock;

public class Writer2 implements Runnable{
	private Data3 feld;
	private ReentrantLock monitor;

	public Writer2(Data3 feld) {
		super();
		this.feld = feld;
		monitor = feld.getMonitor();
	}

	@Override
	public void run() {
		for (int z = 1; z < 11; ++z) {
			monitor.lock();
				feld.write(z);
//			--------------------
				System.out.println("geschrieben: " + z);
			monitor.unlock();
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}

		feld.write(-1);
		System.out.println("Alles geschrieben");

	}

}
