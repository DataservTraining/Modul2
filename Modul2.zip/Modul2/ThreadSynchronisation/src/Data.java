
public class Data {
	
	private int[] zahlen = new int[5];
	private int index;
	
	public synchronized void write(int wert) {
		if(index == zahlen.length) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		zahlen[index] = wert;
		++index;
		if(index==1) {
			this.notifyAll();
		}
	}
	
	public synchronized int read() {
		int temp = zahlen[0];
		if(index == 0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		for(int i = 0; i < index-1; ++i) {
			zahlen[i] = zahlen[i+1];
		}
		
		--index;
		if(index == zahlen.length-1) {
			this.notifyAll();
		}
		return temp;
	}

}
