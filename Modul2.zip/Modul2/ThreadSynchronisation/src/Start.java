
public class Start {

	public static void main(String[] args) {
		Data3 feld = new Data3();
		Thread writerThread = new Thread(new Writer2(feld));
		Thread readerThread = new Thread(new Reader2(feld));
		writerThread.start();
		readerThread.start();
	}

}
