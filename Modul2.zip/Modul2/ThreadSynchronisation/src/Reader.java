
public class Reader implements Runnable {
	private Data3 feld;

	public Reader(Data3 feld) {
		super();
		this.feld = feld;
	}

	@Override
	public synchronized void run() {
		int temp = 0;
//		boolean running = true;
		while (true) {
			
			synchronized (feld) {
				temp = feld.read();
				if (temp == -1) {
					return;
				} else {
					System.out.println("gelesen: " + temp);
				}
			}
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

}
