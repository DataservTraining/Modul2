
public class Data2 {

	private int[] zahlen = new int[5];
	private int index;
	private Object monitor1 = new Object();

	public void write(int wert) {
		synchronized (monitor1) {
			zahlen[index] = wert;
			++index;
		}
	}

	public int read() {
		synchronized (monitor1) {
			int temp = zahlen[0];

			for (int i = 0; i < index; ++i) {
				zahlen[i] = zahlen[i + 1];
			}

			--index;
			return temp;
		}
	}

}
