package DateTime;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Uebung1 {

	public static void main(String[] args) {
		LocalDate geburtstag = LocalDate.of(1900, 3, 23);
		System.out.println(geburtstag);
		LocalTime feierabend = LocalTime.of(17, 30);
		System.out.println(feierabend);
		LocalDateTime now = LocalDateTime.now();
		System.out.println(now);

	}

}
