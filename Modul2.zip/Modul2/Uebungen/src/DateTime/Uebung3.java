package DateTime;

import java.time.LocalDate;
import java.time.Period;

public class Uebung3 {

	public static void main(String[] args) {
		final Period period = Period.of(1, 2, 14);
		System.out.println(period);
		System.out.println(Period.ofYears(1).ofMonths(2).ofDays(14));
		System.out.println(Period.ofYears(1).withMonths(2).withDays(14));
		System.out.println(LocalDate.of(2013, 10, 10).plusYears(1).plusMonths(2).plusDays(14));
	}

}
