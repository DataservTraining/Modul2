package DateTime;

import java.time.LocalDate;
import java.time.Period;

public class Uebung2 {

	public static void main(String[] args) {
		final LocalDate now = LocalDate.now();
		final LocalDate birthday = LocalDate.of(1971, 2, 7);
		System.out.println(birthday.until(now));
		System.out.println(Period.between(birthday, now));

	}

}
