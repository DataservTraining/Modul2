package DateTime;

import java.time.LocalDate;
import java.time.Month;
import java.time.Year;

public class Uebung4 {

	public static void main(String[] args) {
		LocalDate date1 = LocalDate.of(2012, 2, 2);
		LocalDate date2 = LocalDate.of(2014, 2, 2);
		LocalDate date3 = LocalDate.of(2014, 4, 4);
		LocalDate date4 = LocalDate.of(2014, 5, 5);
		
		System.out.println(date1.plusMonths(1));
		System.out.println(date2.plusMonths(1));
		System.out.println(date3.plusMonths(1));
		System.out.println(date4.plusMonths(1));
		System.out.println("======================");
		System.out.println(date1.plusDays(Month.of(date1.getMonthValue()).length(Year.of(date1.getYear()).isLeap())));
		System.out.println(date2.plusDays(Month.of(date2.getMonthValue()).length(Year.of(date2.getYear()).isLeap())));
		System.out.println(date3.plusDays(Month.of(date3.getMonthValue()).length(Year.of(date3.getYear()).isLeap())));
		System.out.println(date4.plusDays(Month.of(date4.getMonthValue()).length(Year.of(date4.getYear()).isLeap())));
		
		
	}

}
