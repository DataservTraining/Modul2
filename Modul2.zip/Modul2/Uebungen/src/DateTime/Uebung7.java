package DateTime;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class Uebung7 {

	public static void main(String[] args) {
		LocalDate weihnachten2013 = LocalDate.of(2013, 12, 24);
		System.out.println(DayOfWeek.from(weihnachten2013));
		
		

	}

}
