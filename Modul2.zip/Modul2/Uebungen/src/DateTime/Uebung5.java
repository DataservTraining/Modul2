package DateTime;

import java.time.ZoneId;
import java.util.Set;
import java.util.stream.Stream;

public class Uebung5 {

	public static void main(String[] args) {
		
		Stream<String> zones = ZoneId.getAvailableZoneIds().stream();
		
		zones.filter(zone -> zone.startsWith("America/L") || zone.startsWith("Europe/S"))
						.forEach(System.out::println);
		
		Set<String> zones2 = ZoneId.getAvailableZoneIds();
		System.out.println("--------------------------");
		for(var zone: zones2) {
			if(zone.startsWith("America/L") || zone.startsWith("Europe/S")) {
				System.out.println(zone);
			}
		}

	}

}
