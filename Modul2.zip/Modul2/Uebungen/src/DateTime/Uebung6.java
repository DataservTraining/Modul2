package DateTime;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Uebung6 {

	public static void main(String[] args) {
		final LocalDate departureDate = LocalDate.of(2014, 7, 7);
		final LocalTime departureTime = LocalTime.of(14, 30);
		final ZoneId zoneEurope = ZoneId.of("Europe/Zurich");
		final ZonedDateTime departure =
		ZonedDateTime.of(departureDate, departureTime, zoneEurope);
		
		System.out.println(departure.plus(Duration.ofHours(11).plusMinutes(30)).withZoneSameInstant(ZoneId.of("America/Los_Angeles")));

	}

}
