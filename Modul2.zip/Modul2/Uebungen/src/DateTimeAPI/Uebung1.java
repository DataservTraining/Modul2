package DateTimeAPI;

import java.time.Duration;
import java.time.Instant;
import java.time.YearMonth;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalField;

public class Uebung1 {

	public static void main(String[] args) {
		YearMonth geburtsMonat = YearMonth.of(1900, 3);
		System.out.println("Schaltjahr? " + geburtsMonat.isLeapYear());
		
		Instant geburtstag = Instant.parse("1900-03-10T00:00:00Z");
		
		Instant weihnachten2021 = Instant.parse("2021-12-24T00:00:00Z");
		Duration zeitZwischenGeburtstagUndWeihnachten = Duration.between(geburtstag, weihnachten2021);
		
		System.out.println(geburtsMonat);
		System.out.println(geburtstag);
		System.out.println(weihnachten2021);
		System.out.println(geburtstag + " - " + weihnachten2021 + ": " + zeitZwischenGeburtstagUndWeihnachten);
		

	}

}
