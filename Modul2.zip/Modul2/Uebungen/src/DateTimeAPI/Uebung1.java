package DateTimeAPI;

import java.time.Duration;
import java.time.Instant;
import java.time.YearMonth;

public class Uebung1 {

	public static void main(String[] args) {
		
	}

}
