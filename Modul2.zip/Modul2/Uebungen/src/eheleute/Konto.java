package eheleute;

public class Konto {
	public double saldo;
	
	public Konto(double saldo) {
		super();
		this.saldo = saldo;
	}

	public void showSaldo() {
		System.out.println("Saldo: " + saldo);
	}
	
	public void abheben(double betrag) throws NoMoneyException {
		if(betrag > saldo) {
			throw new NoMoneyException("Konto leer");
		}
		saldo -= betrag;
	}
}
