package eheleute;

public class Start {

	public static void main(String[] args) {
		Konto konto = new Konto(4000);
		Eheleute eve = new Eheleute("Eve", konto);
		Eheleute bob = new Eheleute("Bob", konto);
		eve.start();
		bob.start();
		

	}

}
