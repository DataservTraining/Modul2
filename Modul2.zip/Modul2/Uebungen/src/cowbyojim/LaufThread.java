package cowbyojim;

public class LaufThread  extends Thread {
	@Override
	public void run() {
		boolean fuss = true;
		while (true) {			
			System.out.println(fuss?"rechts":"links");
			fuss = !fuss;
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				return;
			}
		}
	}
}