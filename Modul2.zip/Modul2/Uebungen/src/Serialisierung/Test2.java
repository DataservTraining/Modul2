package Serialisierung;

public class Test2 {
	private double atrribute1 = 4.5; 
	private int atrribute2 = 67;
	private String atrribute3 = "Welt";
	private boolean atrribute4 = true;
	public double getAtrribute1() {
		return atrribute1;
	}
	public void setAtrribute1(double atrribute1) {
		this.atrribute1 = atrribute1;
	}
	public int getAtrribute2() {
		return atrribute2;
	}
	public void setAtrribute2(int atrribute2) {
		this.atrribute2 = atrribute2;
	}
	public String getAtrribute3() {
		return atrribute3;
	}
	public void setAtrribute3(String atrribute3) {
		this.atrribute3 = atrribute3;
	}
	public boolean isAtrribute4() {
		return atrribute4;
	}
	public void setAtrribute4(boolean atrribute4) {
		this.atrribute4 = atrribute4;
	}
	@Override
	public String toString() {
		return "Test2 [atrribute1=" + atrribute1 + ", atrribute2=" + atrribute2 + ", atrribute3=" + atrribute3
				+ ", atrribute4=" + atrribute4 + "]";
	}
	
	
	

}
