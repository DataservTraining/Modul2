package Serialisierung;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Test1 implements Serializable{
	private static final long serialVersionUID = 1L;
	private double wert1 = 1.5;
	private int wert2 = 2;
	private String wert3 = "Hallo";
	private transient Test2 test2 = new Test2();
	
	public double getWert1() {
		return wert1;
	}
	public void setWert1(double wert1) {
		this.wert1 = wert1;
	}
	public int getWert2() {
		return wert2;
	}
	public void setWert2(int wert2) {
		this.wert2 = wert2;
	}
	public String getWert3() {
		return wert3;
	}
	public void setWert3(String wert3) {
		this.wert3 = wert3;
	}
	@Override
	public String toString() {
		return "Test1 [wert1=" + wert1 + ", wert2=" + wert2 + ", wert3=" + wert3 + ", test2=" + test2 + "]";
	}
	
	private void readObject(ObjectInputStream in) throws ClassNotFoundException, IOException {
		in.defaultReadObject();
		test2 = new Test2();
		test2.setAtrribute1(in.readDouble());
		test2.setAtrribute2(in.readInt());
		test2.setAtrribute3(in.readUTF());
		test2.setAtrribute4(in.readBoolean());
	}
	
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		out.writeDouble(test2.getAtrribute1());
		out.writeInt(test2.getAtrribute2());
		out.writeUTF(test2.getAtrribute3());
		out.writeBoolean(test2.isAtrribute4());
	}
	
	
}
