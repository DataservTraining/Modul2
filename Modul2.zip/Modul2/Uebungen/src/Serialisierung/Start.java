package Serialisierung;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Start {

	public static void main(String[] args) {
		Test1 test1 = new Test1();
		
		try {
			ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("testdaten.dat")));
			out.writeObject(test1);
			out.close();
			System.out.println(test1);
			
			ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream("testdaten.dat")));
			Test1 test = (Test1) in.readObject();
			in.close();
			System.out.println(test);
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
