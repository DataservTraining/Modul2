import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class PeriodenBerechnung {

	public static void main(String[] args) {
		final LocalDateTime start = LocalDateTime.of(1972, 2, 7, 10, 11);
		final Period thirtyOneDays = Period.ofDays(31);
		final Period fourWeeks = Period.ofWeeks(4);
		final Period oneMonth = Period.ofMonths(1);
		System.out.println("7.2.1971 + 31 Tage: " + start.plus(thirtyOneDays));
		System.out.println("7.2.1971 + 4 Wochen: " + start.plus(fourWeeks));
		System.out.println("7.2.1971 + 1 Monat: " + start.plus(oneMonth));
		System.out.println(start.plusMinutes(25));
		System.out.println(start.plus(fourWeeks));
		
		LocalDate heute = LocalDate.now();
		System.out.println(heute);
		System.out.println(heute.plusMonths(2));
		
		LocalTime jetzt = LocalTime.now();
		System.out.println(jetzt);
		System.out.println(jetzt.plus(1, ChronoUnit.HOURS));
		

	}

}
