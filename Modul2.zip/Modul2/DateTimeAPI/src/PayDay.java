import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

public class PayDay {

	public static void main(String[] args) {
		final LocalDate jan = LocalDate.of(2022, Month.NOVEMBER, 30);
		final LocalDate nextPayday1 = jan.with(new NextPaydayAdjuster());
		final LocalDate feb = LocalDate.of(2015, Month.FEBRUARY, 7);
		final LocalDate nextPayday2 = feb.with(new NextPaydayAdjuster());
		System.out.println("Next Payday Jan: " + nextPayday1);
		System.out.println("Next Payday Feb: " + nextPayday2);

	}

	static class NextPaydayAdjuster implements TemporalAdjuster {
		@Override
		public Temporal adjustInto(final Temporal temporal) {
			LocalDate date = LocalDate.from(temporal);

			boolean isDecember = date.getMonth().equals(Month.DECEMBER);
			int paymentDay = isDecember ? 15 : 25;

			if (date.getDayOfMonth() > paymentDay) {
				date = date.plusMonths(1);
				// Abfragen nochmals n�tig, da eventuell um einen Monat verschoben
				isDecember = date.getMonth().equals(Month.DECEMBER);
				paymentDay = isDecember ? 15 : 25;
			}

			date = date.withDayOfMonth(paymentDay);
			
			if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
				if (isDecember) {
					date = date.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
				} else
					date = date.with(TemporalAdjusters.previous(DayOfWeek.FRIDAY));
			}

			
			return temporal.with(date);
		}
	}

}
