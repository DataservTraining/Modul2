import java.time.Month;
import java.time.MonthDay;
import java.time.Year;
import java.time.YearMonth;

public class MonthDayTest {

	public static void main(String[] args) {
		// MonthDay: Achtung, ISO-Format mit der Reihenfolge: Monat, Tag
		final MonthDay monthDay = MonthDay.of(Month.FEBRUARY, 7);
		// YearMonth: Zur Lesbarkeit besser Month statisch importieren
		final YearMonth yearMonth = YearMonth.of(2016, Month.FEBRUARY);
		// Year
		final Year year = Year.of(2013);
		System.out.println("MonthDay: " + monthDay);
		System.out.println("YearMonth: " + yearMonth+ " / isLeap? " + yearMonth.isLeapYear());
		System.out.println("Year: " + year + " / isLeap? " + year.isLeap());

	}

}
