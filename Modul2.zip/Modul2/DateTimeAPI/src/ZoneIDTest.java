import java.time.ZoneId;
import java.util.Set;

public class ZoneIDTest {

	public static void main(String[] args) {
		Set<String> zoneIds = ZoneId.getAvailableZoneIds();
		
		for(var id : zoneIds) {
			System.out.println(id);
		}
				
				
				
				

	}

}
