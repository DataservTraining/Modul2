import java.time.Instant;
import java.time.temporal.ChronoUnit;

public class ChronoUnitTest {

	public static void main(String[] args) {
		// Abfahrt jetzt und Reisedauer 5 Stunden
		final Instant departureTime = Instant.now();
		final Instant arrivalTime = departureTime.plus(5, ChronoUnit.HOURS);
		System.out.println("departure now: " + departureTime);
		System.out.println("arrival now + 5h: " + arrivalTime);
		// Berechnungen durchf�hren: Differenz bilden
		final long inBetweenHours = ChronoUnit.HOURS.between(departureTime,
		arrivalTime);
		final long inBetweenMinutes = ChronoUnit.MINUTES.between(departureTime,
		arrivalTime);
		final long inBetweenDays = ChronoUnit.DAYS.between(departureTime,
				arrivalTime);
		
		System.out.println("inBetweenHours: " + inBetweenHours);
		System.out.println("inBetweenMinutes: " + inBetweenMinutes);
		System.out.println("inBetweenDays: " + inBetweenDays);
		
		Instant now = Instant.now();
		System.out.println(now);
		System.out.println(ChronoUnit.HOURS.addTo(now, 3));

	}

}
