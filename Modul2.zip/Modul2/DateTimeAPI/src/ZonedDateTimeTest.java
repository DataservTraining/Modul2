import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ZonedDateTimeTest {

	public static void main(String[] args) {
		// Aktuelle Zeit als ZonedDateTime-Objekt ermitteln
		final ZonedDateTime now = ZonedDateTime.now();
		// Die Uhrzeit �ndern und in neuem Objekt speichern
		final ZonedDateTime nowButChangedTime = now.withHour(11).withMinute(44);
		// Neues Objekt mit ver�ndertem Datum erzeugen
		final ZonedDateTime dateAndTime = nowButChangedTime.withYear(2008).
		withMonth(9).
		withDayOfMonth(29);
		// Einsatz einer Monatskonstanten und wechseln der Zeitzone
		final ZonedDateTime dateAndTime2 = nowButChangedTime.withYear(2008).
		withMonth(Month.SEPTEMBER.getValue()).
		withDayOfMonth(29).
		withZoneSameInstant(ZoneId.of("GMT"));
		System.out.println("now: " + now);
		System.out.println("-> 11:44: " + nowButChangedTime);
		System.out.println("-> 29.9.2008: " + dateAndTime);
		System.out.println("-> 29.9.2008: " + dateAndTime2);
		System.out.println(ZonedDateTime.now().withZoneSameInstant(ZoneId.of("America/Los_Angeles")));

	}

}
