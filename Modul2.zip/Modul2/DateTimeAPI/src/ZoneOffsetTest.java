import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.stream.Stream;

public class ZoneOffsetTest {

	public static void main(String[] args) {
		final Stream<String> zoneIdNames = Stream.of("Europe/Berlin", "America/Los_Angeles", "Australia/Adelaide");
		
		zoneIdNames.forEach(zoneIdName -> {
			final ZoneId zoneId = ZoneId.of(zoneIdName);
			final LocalDateTime ldt = LocalDateTime.now();
			final ZonedDateTime zdt = ldt.atZone(zoneId);
			final ZoneOffset offset = zdt.getOffset();
			System.out.format("offset for �%s� is %s\n", zoneId, offset);
		});

	}

}
