import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class TemporalAdjusterTest {

	public static void main(String[] args) {
		final LocalDate date = LocalDate.of(2015, Month.FEBRUARY, 7);
		LocalDate firstOfMonth = date.with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastofMonth = date.with(TemporalAdjusters.lastDayOfMonth());
		LocalDate firstOfNextMonth = date.with(TemporalAdjusters.firstDayOfNextMonth());
		LocalDate firstMondayInMonth = date.with(TemporalAdjusters.firstInMonth(DayOfWeek.MONDAY));
		LocalDate lastSaturdayInMonth = date.with(TemporalAdjusters.lastInMonth(DayOfWeek.SATURDAY));
		
		System.out.println("date: " + date + "(" + date.getDayOfWeek() + ")");
		System.out.println("lastofMonth: " + lastofMonth);
		System.out.println("firstOfMonth: " + firstOfMonth);
		System.out.println("firstOfNextMonth: " + firstOfNextMonth);
		System.out.println("firstMondayInMonth: " + firstMondayInMonth);
		System.out.println("lastSaturdayInMonth: " + lastSaturdayInMonth);
		
		System.out.println(date.with(TemporalAdjusters.previous(DayOfWeek.SATURDAY)));
		System.out.println(date.with(TemporalAdjusters.dayOfWeekInMonth(3, DayOfWeek.MONDAY)));
		System.out.println(date.with(TemporalAdjusters.firstDayOfNextYear()));
		System.out.println(LocalDate.now().with(TemporalAdjusters.dayOfWeekInMonth(-3, DayOfWeek.THURSDAY)));
		

	}

}
