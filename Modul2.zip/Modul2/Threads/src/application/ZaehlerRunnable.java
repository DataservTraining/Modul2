package application;

public class ZaehlerRunnable implements Runnable{

	@Override
	public void run() {
		for(int zaehler = 1; zaehler < 100; ++zaehler) {
			System.out.println(Thread.currentThread().getName() + ": " + zaehler);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				return;
			}
		}
	}

}
