package application;

public class ZaehlerThread extends Thread
{

	@Override
	public void run() {
		for(int zaehler = 1; zaehler < 100; ++zaehler) {
			System.out.println("Z�hler: " + zaehler);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
