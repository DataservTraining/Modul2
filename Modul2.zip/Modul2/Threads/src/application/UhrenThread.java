package application;

import java.time.Instant;

public class UhrenThread extends Thread {

	@Override
	public void run() {
		while (true) {
			Instant now = Instant.now();
			System.out.println(now);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
