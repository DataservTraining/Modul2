package application;

public class Adder implements Runnable{

	private int summe;
	@Override
	public void run() {
		for(int i = 1; i < 1000; ++i) {
			summe += i;
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public int getsumme() {
		return summe;
	}

}
