package application;

import java.lang.Thread.State;

public class Start {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread().getId());
		System.out.println(Thread.currentThread().getName());
		UhrenRunnable uhrenRunnable = new UhrenRunnable();
		Adder adder = new Adder();
		Thread uhr = new Thread(uhrenRunnable, "Uhr");
		Thread zaehler = new Thread(new ZaehlerRunnable(), "Z�hler");
		Thread adderThread = new Thread(adder, "Adder");
		uhr.setDaemon(true);
		State status = adderThread.getState();
		System.out.println("1. Status: " + status.name());
		uhr.start();
		zaehler.start();
		adderThread.start();
		status = adderThread.getState();
		System.out.println("1. Status: " + status.name());
		
		
		
		status = adderThread.getState();
		System.out.println("2. Status: " + status.name());
		adderThread.join();
		
		status = adderThread.getState();
		System.out.println("3. Status: " + status.name());
		int ergebnis = adder.getsumme();
		System.out.println("Summe: " + ergebnis);
		System.out.println("priorit�t: " + adderThread.getPriority());
		adderThread.setPriority(2);
		ThreadGroup group = adderThread.getThreadGroup();
		System.out.println("Gruppe: " + group.getName());
		
		
		Thread.sleep(1000);
		System.out.println("priorit�t: " + adderThread.getPriority());
//		uhrenRunnable.uhrStoppen();
		zaehler.interrupt();
		
		System.out.println("Ende main()");
		
		
		
	}

}
