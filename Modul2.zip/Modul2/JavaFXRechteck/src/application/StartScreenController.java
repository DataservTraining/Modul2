package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;

public class StartScreenController implements Initializable {
	
	@FXML
    private Rectangle rectangle;

    @FXML
    private Slider sldBreite;

    @FXML
    private Slider sldLaenge;

    @FXML
    private TextField txtBreite;

    @FXML
    private TextField txtLaenge;

	@Override
	public void initialize(URL url, ResourceBundle resources) {
		
		
	}

}
