package application;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Start {

	public static void main(String[] args) {
		List<Person> personen = DemoData.createDemoData();

		try {
			

			ObjectOutput outO = new ObjectOutputStream(new FileOutputStream("personen.dat"));
			for (Person p : personen) {
				outO.writeObject(p);
			}
			outO.close();

			ObjectInputStream inO = new ObjectInputStream(new FileInputStream("personen.dat"));

			List<Person> gelesen = new ArrayList<Person>();
			while (true) {
				try {
					Person p = (Person) inO.readObject();
					gelesen.add(p);
				} catch (EOFException e) {
					break;
				} 
			}
			
			inO.close();
			
			for(Person p : gelesen) {
				System.out.println(p);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
