package application;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Person extends Lebewesen implements Comparable<Person>, Serializable{
	private static final long serialVersionUID = 1L;
	private String name = "unbekannt";
	private int age = 1;
	private String favoriteColor;
	private String city;
	private transient Adresse adresse;
//	private transient LocalDate birthday;
	private int id;	
	
	

	public Person() {
		this("Willi Meier", 34);
		// TODO Auto-generated constructor stub
	}

	public Person(String name, int age) {
		this(name, age, "none", "M�nchen", LocalDate.now());
	}

	public Person(String name, int age, String favoriteColor, String city, LocalDate birthday) {
		super("");
		this.name = name;
		this.age = age;
		this.favoriteColor = favoriteColor;
		this.city = city;
		adresse = new Adresse();
//		this.birthday = birthday;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setFavoriteColor(String favoriteColor) {
		this.favoriteColor = favoriteColor;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	
	public String getFavoriteColor() {
		return favoriteColor;
	}

	public boolean isAdult() {
		return age >= 18;
	}
	
	

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

//	public LocalDate getBirthday() {
//		return birthday;
//	}
//
//	public void setBirthday(LocalDate birthday) {
//		this.birthday = birthday;
//	}

	public boolean livesIn(final String city) {
		return Objects.equals(this.city, city);
	}

	
	@Override
	public int compareTo(Person o) {
		// wenn this vor o einsortiert wird liefert compareTo Wert < 0
		// wenn this an gleicher Stelle wie o einsortiert wird liefert compareTo Wert 0
		// wenn this nach o einsortiert wird liefert compareTo Wert > 0
		return this.name.compareTo(o.name);
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", adresse=" + adresse + "]";
	}

//	@Override
//	public String toString() {
//		return "Person [name=" + name + ", age=" + age + ", favoriteColor=" + favoriteColor + ", city=" + city
//				+ ", birthday=" + "]";
//	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		out.writeUTF(adresse.getStrasse());
		out.writeUTF(adresse.getOrt());
		out.writeInt(adresse.getHausnummer());
		out.writeInt(adresse.getPlz());
	}

	private void readObject(ObjectInputStream in) throws ClassNotFoundException, IOException {
		in.defaultReadObject();
		adresse = new Adresse(in.readUTF(), in.readUTF(), in.readInt(), in.readInt());
	}
}