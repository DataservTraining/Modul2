package application;



public class Adresse {
	private String strasse;
	private String ort;
	private int hausnummer;
	private int plz;
	
	
	public Adresse() {
		this("Musterweg", "Musterstadt", 100, 23445);
	}


	public Adresse(String strasse, String ort, int hausnummer, int plz) {
		super();
		this.strasse = strasse;
		this.ort = ort;
		this.hausnummer = hausnummer;
		this.plz = plz;
	}


	public String getStrasse() {
		return strasse;
	}


	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}


	public String getOrt() {
		return ort;
	}


	public void setOrt(String ort) {
		this.ort = ort;
	}


	public int getHausnummer() {
		return hausnummer;
	}


	public void setHausnummer(int hausnummer) {
		this.hausnummer = hausnummer;
	}


	public int getPlz() {
		return plz;
	}


	public void setPlz(int plz) {
		this.plz = plz;
	}


	@Override
	public String toString() {
		return "Adresse [strasse=" + strasse + ", ort=" + ort + ", hausnummer=" + hausnummer + ", plz=" + plz + "]";
	}
	
	
	
	
	
	
	
}
