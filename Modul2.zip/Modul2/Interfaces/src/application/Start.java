package application;

public class Start {

	public static void main(String[] args) {
		TestInterface t = new TestInterface();
		t.test();
		t.test2();
		System.out.println("===============================");
		InterfaceA.testStatic();
	

	}

}
