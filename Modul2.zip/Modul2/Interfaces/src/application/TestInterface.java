package application;

public class TestInterface implements InterfaceA, InterfaceB{

	
	
	@Override
	public void test() {
		System.out.println("test()");
		
	}

	@Override
	public int test2() {
		
		return InterfaceA.super.test2();
	}

}
