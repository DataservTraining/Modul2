package application;

@FunctionalInterface
public interface InterfaceA {

	public static final int X = 10; // Java 1.0

	void test(); // Java 1.0
	//boolean equals(String o); // Java 1.0

	public default int test2() {
		System.out.println("InterfaceA.test2()");
		testPrivate();
		testPrivateStatic();
		return 0;
	} // Java 8

	public static void testStatic() {
		System.out.println("InterfaceA.testStatic()");
		testPrivateStatic();
	} // Java 8

	private void testPrivate() {
		System.out.println("InterfaceA.testPrivate()");
	} // Java 9

	private static void testPrivateStatic() {
		System.out.println("InterfaceA.testPrivateStatic()");
	} // Java 9

}
