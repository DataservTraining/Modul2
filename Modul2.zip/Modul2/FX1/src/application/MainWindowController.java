package application;


import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class MainWindowController implements Initializable{
	 	@FXML
	    private Button btnUebernehmen;

	    @FXML
	    private Label lblAusgabe;

	    @FXML
	    private TextField txtEingabe;

	    @Override
		public void initialize(URL url, ResourceBundle bundle) {
			btnUebernehmen.setOnAction(this::btnUebernehmenHandler);
			
		}
	    	    
	    void btnUebernehmenHandler(ActionEvent e) {
	    	lblAusgabe.setText(txtEingabe.getText());
	    }

		
	    
	    

}



