package application;

import java.net.URL;
import java.util.ResourceBundle;

import entities.Rechteck;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Slider;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.util.converter.NumberStringConverter;

public class MyApplicationController implements Initializable {
	private ResourceBundle resources;
	private Rechteck rechteck = null;
	private StringConverter<Number> converter = new NumberStringConverter();
	private ObservableList<Rechteck> rechtecke = FXCollections.observableArrayList();
	@FXML
	private Button btnNewButton;

	@FXML
	private Button btnSaveButton;

	@FXML
	private Rectangle rectangle;

	@FXML
	private ColorPicker colorChooser;

	@FXML
	private CheckBox chkFilled;

	@FXML
	private TextField txtLength;

	@FXML
	private TextField txtWidth;

	@FXML
	private Slider sliderWidth;

	@FXML
	private Slider sliderLength;

	@FXML
	private TableView<Rechteck> tblRectangle;

	@FXML
	private TableColumn<Rechteck, Integer> colBreite;

	@FXML
	private TableColumn<Rechteck, Integer> colLaenge;

	@FXML
	private TableColumn<Rechteck, Integer> colFlaeche;

	@FXML
	private TableColumn<Rechteck, Color> colColor;

	@FXML
	private TableColumn<Rechteck, Boolean> colFilled;

	void btnNewButtonHandler(ActionEvent event) {
		System.out.println("==================================");
		rechteck = new Rechteck();
		init(true);
		rechteck.breiteProperty().bindBidirectional(sliderWidth.valueProperty());
		rechteck.laengeProperty().bindBidirectional(sliderLength.valueProperty());
		rechteck.filledProperty().bind(chkFilled.selectedProperty());
		rechteck.colorProperty().bind(colorChooser.valueProperty());
		rectangle.setFill(rechteck.getFilled() ? rechteck.getColor() : Color.TRANSPARENT);
		rectangle.strokeProperty().bind(rechteck.colorProperty());
		Bindings.bindBidirectional(txtWidth.textProperty(), rechteck.breiteProperty(), converter);
		Bindings.bindBidirectional(txtLength.textProperty(), rechteck.laengeProperty(), converter);
		rectangle.widthProperty().bind(rechteck.breiteProperty());
		rectangle.heightProperty().bind(rechteck.laengeProperty());
	}

	void fillRectangle() {
		rectangle.setFill(rechteck.getFilled() ? rechteck.getColor() : Color.TRANSPARENT);
	}

	void btnSaveButtonHandler(ActionEvent event) {
		rechteck.breiteProperty().unbindBidirectional(sliderWidth.valueProperty());
		rechteck.laengeProperty().unbindBidirectional(sliderLength.valueProperty());
		rechteck.filledProperty().unbind();
		rechteck.colorProperty().unbind();
		Bindings.unbindBidirectional(txtWidth.textProperty(), rechteck.breiteProperty());
		Bindings.unbindBidirectional(txtLength.textProperty(), rechteck.laengeProperty());
		rectangle.widthProperty().bind(rechteck.breiteProperty());
		rectangle.heightProperty().unbind();
		rechtecke.add(rechteck);
		init(false);
	}

	void colorChooserHandler(ActionEvent event) {
		fillRectangle();
	}

	void txtLengthHandler(ActionEvent event) {
	}

	void txtWidthHandler(ActionEvent event) {
	}

	void chkFilledHandler(ActionEvent event) {
		fillRectangle();
	}

	void sliderWidthHandler(ObservableValue<? extends Object> observable, Object oldValue, Object newValue) {
	}

	void sliderLengthHandler(ObservableValue<? extends Object> observable, Object oldValue, Object newValue) {
	}

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.resources = resources;
		btnNewButton.setOnAction(this::btnNewButtonHandler);
		btnSaveButton.setOnAction(this::btnSaveButtonHandler);
		colorChooser.setOnAction(this::colorChooserHandler);
		chkFilled.setOnAction(this::chkFilledHandler);
		txtLength.setOnAction(this::txtLengthHandler);
		txtWidth.setOnAction(this::txtWidthHandler);
		sliderWidth.valueProperty().addListener(this::sliderWidthHandler);
		sliderLength.valueProperty().addListener(this::sliderLengthHandler);
		tblRectangle.setItems(rechtecke);
		colBreite = (TableColumn<Rechteck, Integer>) tblRectangle.getColumns().get(0);
		colLaenge = (TableColumn<Rechteck, Integer>) tblRectangle.getColumns().get(1);
		colFlaeche = (TableColumn<Rechteck, Integer>) tblRectangle.getColumns().get(2);
		colColor = (TableColumn<Rechteck, Color>) tblRectangle.getColumns().get(3);
		colFilled = (TableColumn<Rechteck, Boolean>) tblRectangle.getColumns().get(4);
		colBreite.setText("Breite");
		colLaenge.setText("Länge");
		colFlaeche.setText("Fläche");
		colColor.setText("Farbe");
		colFilled.setText("gefüllt");
		colLaenge.setText("Länge");
		colFlaeche.setText("Fläche");
		colColor.setText("Farbe");
		colFilled.setText("gefüllt");
		colBreite.setCellValueFactory(new PropertyValueFactory<Rechteck, Integer>("breite"));
		colLaenge.setCellValueFactory(new PropertyValueFactory<Rechteck, Integer>("laenge"));
		colFlaeche.setCellValueFactory(new PropertyValueFactory<Rechteck, Integer>("flaeche"));
		colFilled.setCellValueFactory(new PropertyValueFactory<Rechteck, Boolean>("filled"));
		colFilled.setCellFactory(CheckBoxTableCell.forTableColumn(colFilled));
//		colColor.setCellValueFactory(new PropertyValueFactory<Rechteck, Color>("color"));
		colColor.setCellFactory(new ColorCellFactory());

		init(false);
	}

	private void init(boolean active) {
		if (rechteck != null) {
			txtWidth.setText(Integer.toString(rechteck.getBreite()));
			txtLength.setText(Integer.toString(rechteck.getLaenge()));
			chkFilled.setSelected(false);
			colorChooser.setValue(Color.WHITE);
			sliderWidth.setValue(rechteck.getBreite());
			sliderLength.setValue(rechteck.getLaenge());
		}
		txtWidth.setDisable(!active);
		txtLength.setDisable(!active);
		chkFilled.setDisable(!active);
		colorChooser.setDisable(!active);
		sliderWidth.setDisable(!active);
		sliderLength.setDisable(!active);
		btnNewButton.setDisable(active);
		btnSaveButton.setDisable(!active);
	}

	class ColorCellFactory implements Callback<TableColumn<Rechteck, Color>, TableCell<Rechteck, Color>> {

		@Override
		public TableCell<Rechteck, Color> call(TableColumn<Rechteck, Color> param) {

			return new TableCell<Rechteck, Color>() {
				@Override
				public void updateIndex(int i) {
					System.out.println("index: " + i);
//					super.updateIndex(i);
					// select color based on index of row/column
					if (i> -1 && i < rechtecke.size()) {
						Rechteck r = rechtecke.get(i);
						String color = r.getColor().toString();
						System.out.println(color);
						this.setStyle("-fx-background-color: #" + color.substring(2, 8) + ";");
					}
				}
		};
		}

	}

}
