package application;

import java.util.Arrays;

public class MyArrayList<T> {
	
	private T[] data;
	private int index;
	
	@SuppressWarnings("unchecked")
	
	public MyArrayList() {
		super();
		data = (T[]) new Object[10];
	}
	
	public static <T> void test(T o) {
		System.out.println(o);
	}
	
	@SuppressWarnings("unchecked")
	public static <T extends Integer> T plus(T o1, T o2) {
		Integer temp = (Integer)o1 + (Integer)o2;
		return (T) temp;
	}
	
	public void add(T o) {
		if(index == data.length) {
			resize();
		}
		data[index++] = o;
	}
	
	T get(int index) {
		if( index < 0 || index >= data.length) {
			throw new IllegalArgumentException("index unzul�ssig!");
		}
		return data[index];
	}

	private void resize() {
		data = Arrays.copyOf(data, data.length * 2);
	}

}
