package application;

import java.util.ArrayList;
import java.util.List;

public class Start2 {

	public static void main(String[] args) {
		List<Animal> animals = new ArrayList<Animal>();
		List<Dog> dogs = new ArrayList<Dog>();
		List<Cat> cats = new ArrayList<Cat>();
		Dog dog = new Dog();
		Cat cat = new Cat();
		animals.add(cat);
		animals.add(dog);
		dogs.add(dog);
		cats.add(cat);
		
		alleImpfen(animals);
		alleImpfen(dogs);
		alleImpfen(cats);
		
		List<Object> objects = new ArrayList<Object>();
		
		
		hinzufuegen(animals);
		hinzufuegen(objects);

	}
	
	public static void alleImpfen(List<? extends Animal> animals) {
		//animals.add(new Cat());
		for(Animal a : animals) {
			a.impfen();
		}
	}

	public static void hinzufuegen(List<? super Animal> animals) {
		animals.add(new Animal());
		animals.add(new Cat());
		animals.add(new Dog());
//		animals.add(new Object());
	}
}
