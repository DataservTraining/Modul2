package application;

public class Animal {
	public void impfen() {
		System.out.println("animal geimpft!");
	}
}
