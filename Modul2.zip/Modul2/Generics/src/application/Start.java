package application;

import java.util.ArrayList;
import java.util.List;

public class Start {

	public static void main(String[] args) {
		List<String> strings = new ArrayList<>();

	}

}
