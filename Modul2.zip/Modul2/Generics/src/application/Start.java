package application;

import java.util.ArrayList;
import java.util.List;

public class Start {

	public static void main(String[] args) {
		List<String> strings = new ArrayList<>();
		List<Person> personen = new ArrayList<Person>();
		List<Integer> integers = new ArrayList<Integer>();
		
		strings.add("Test");
		personen.add(new Person("Willi", "Wuff", 12)) ;
		Person p = personen.get(0);
		String Text = strings.get(0);
		
		MyArrayList<String> strings2 = new MyArrayList<String>();
		strings.add("");
		String text2 = strings2.get(0);
		
		MyArrayList.test(new Person());

	}

}
