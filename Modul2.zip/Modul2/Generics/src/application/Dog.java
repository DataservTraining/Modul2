package application;

public class Dog extends Animal {

}
