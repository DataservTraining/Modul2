package application;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;

public class MainWindow extends JFrame{
	private static final long serialVersionUID = 1L;
	private JButton btnUebernehmen;
	private JTextField txtEingabe;
	private JLabel lblAusgabe;
	private JButton btnButton2;
	private JButton btnHintergrundAendern;

	public MainWindow(String title) throws HeadlessException {
		super(title);
		init();
		this.setVisible(true);
	}

	private void init() {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
//		this.setBounds(200, 200, 800, 600);
		this.setSize(800, 600);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		
		this.setJMenuBar(createMenuBar());
		
		
		btnUebernehmen = new JButton("�bernehmen");
		btnUebernehmen.setBounds(30, 30, 120, 20);
		btnUebernehmen.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnUebnehmenHandler(e);		
			}
		});
		
		btnButton2 = new JButton("Farbe �ndern");
		btnButton2.setBounds(30, 80, 120, 20);
		btnButton2.setForeground(Color.BLACK);
		btnButton2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnButton2Handler(e);
				
			}
		});
		btnHintergrundAendern = new JButton("Farbe �ndern");
		btnHintergrundAendern.setBounds(30, 130, 120, 20);
		btnHintergrundAendern.setForeground(Color.BLACK);
		btnHintergrundAendern.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnHintergrundAendernHandler(e);
				
			}
		});
		
		btnHintergrundAendern.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
		btnHintergrundAendern.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {
				btnHintergrundAenderMouseHandler(e);
			}
			
		
		});
		
		txtEingabe = new JTextField();
		txtEingabe.setBounds(200, 30, 400, 20);
		
		lblAusgabe = new JLabel("Ausgabe");
		lblAusgabe.setBounds(200, 80, 400, 20);
		
		this.add(btnUebernehmen);
		this.add(btnButton2);
		this.add(lblAusgabe);
		this.add(txtEingabe);
		this.add(btnHintergrundAendern);
		
	}

	private JMenuBar createMenuBar() {
		JMenuBar bar = new JMenuBar();
		
		JMenu mnuDatei = new JMenu("Datei");
		
		JMenuItem mnuDateiOeffnen = new JMenuItem("�ffnen");
		JMenuItem mnuDateiSpeichern = new JMenuItem("speichern");
		JMenuItem mnuDateiBeenden = new JMenuItem("beenden");
		
		mnuDatei.add(mnuDateiOeffnen);
		mnuDatei.add(mnuDateiSpeichern);
		mnuDatei.addSeparator();
		mnuDatei.add(mnuDateiBeenden);

		JMenu mnuBearbeiten = new JMenu("Bearbeiten");
		
		JMenuItem mnuBearbeitenHintergrundAendern = new JMenuItem("Hintergrund �ndern");
		JMenuItem mnuBearbeitenUebernehmen = new JMenuItem("�bernehmen");
		JMenuItem mnuBearbeitenFarbeAendern = new JMenuItem("Farbe �ndern");
		mnuBearbeitenHintergrundAendern.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnHintergrundAendernHandler(e);
				
			}
		});
		
		mnuBearbeitenFarbeAendern.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnButton2Handler(e);

			}
		});
		
		mnuBearbeitenUebernehmen.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnUebnehmenHandler(e);
				
			}
		});
		
		mnuDatei.add(mnuBearbeitenFarbeAendern);
		mnuDatei.add(mnuBearbeitenHintergrundAendern);
		
		mnuDatei.add(mnuBearbeitenUebernehmen);
		
		mnuBearbeiten.add(mnuBearbeitenUebernehmen);
		mnuBearbeiten.add(mnuBearbeitenHintergrundAendern);
		mnuBearbeiten.add(mnuBearbeitenFarbeAendern);
		bar.add(mnuDatei);
		bar.add(mnuBearbeiten);
		return bar;
	}

	protected void btnHintergrundAenderMouseHandler(MouseEvent e) {
//		btnHintergrundAendern.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
	}

	protected void btnHintergrundAendernHandler(ActionEvent e) {
		this.getContentPane().setBackground(Color.YELLOW);
		
	}

	protected void btnButton2Handler(ActionEvent e) {
		
		if(btnButton2.getForeground().equals(Color.BLACK)){
			btnButton2.setForeground(Color.BLUE);
		} else {
			btnButton2.setForeground(Color.BLACK);
		}
		
	}

	protected void btnUebnehmenHandler(ActionEvent e) {
		lblAusgabe.setText(txtEingabe.getText());
		
	}
	
	

}
