package application;

import java.awt.BorderLayout;
import java.awt.HeadlessException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class MainWindow extends JFrame{
	private static final long serialVersionUID = 1L;
	private JButton btnUebernehmen;
	private JTextField txtEingabe;
	private JLabel lblAusgabe;
	private JButton btnButton2;

	public MainWindow(String title) throws HeadlessException {
		super(title);
		init();
		this.setVisible(true);
	}

	private void init() {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
//		this.setBounds(200, 200, 800, 600);
		this.setSize(800, 600);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		
		
		btnUebernehmen = new JButton("�bernehmen");
		btnUebernehmen.setBounds(30, 30, 120, 20);
		
		btnButton2 = new JButton("Button 2");
		btnButton2.setBounds(30, 80, 120, 20);
		
		txtEingabe = new JTextField();
		txtEingabe.setBounds(200, 30, 400, 20);
		
		lblAusgabe = new JLabel("Ausgabe");
		lblAusgabe.setBounds(200, 80, 400, 20);
		
		this.add(btnUebernehmen);
		this.add(btnButton2);
		this.add(lblAusgabe);
		this.add(txtEingabe);
		
	}
	
	

}
