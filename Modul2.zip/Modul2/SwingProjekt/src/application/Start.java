package application;

public class Start {

	public static void main(String[] args) {
		new MainWindow("erstes Fenster");

	}

}
